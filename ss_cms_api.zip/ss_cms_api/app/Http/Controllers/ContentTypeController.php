<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\TokensController;
use DB;

class ContentTypeController extends Controller {

    public function get_ContentTypes(Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {
            $ContentType = DB::select("CALL ContentTypeCms_GetAll();");
            $rows = count($ContentType);
            if ($rows > 0) {
                return response()->json(["Response" => $ContentType, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function get_ContentType($id, Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $ContentType = DB::select("call ContentTypeCms_GetXId('$id');");

            $rows = count($ContentType);

            if ($rows > 0) {
                return response()->json(["Response" => $ContentType, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function insert_ContentType(Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = true; //Se deja en true para no cambiar toda la estructura.

        if ($authorization == true) {

            $NAME = $request->ContentType_name;
            $SHOW = $request->ContentType_show;

            $ContentType = DB::insert("CALL ContentTypeCms_Add('$NAME', '$SHOW');");
            if ($ContentType) {
                return response()->json(["Response" => 1, "Message" => "Information registered successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error registering information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function update_ContentType(Request $request) {
        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $ID = $request->ContentType_id;
            $NAME = $request->ContentType_name;
            $SHOW = $request->ContentType_show;

            $ContentType = DB::update("CALL ContentTypeCms_Update('$ID', '$NAME', '$SHOW');");
            if ($ContentType) {
                return response()->json(["Response" => 1, "Message" => "Information registered successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error registering information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }
    
    public function delete_ContentType($id, Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $users = DB::delete("CALL ContentTypeCms_Delete('$id');");
            if ($users > 0) {
                return response()->json(["Response" => 1, "Message" => "Information deleted successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error deleting information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

}
