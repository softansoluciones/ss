-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 26-05-2020 a las 06:27:14
-- Versión del servidor: 10.4.11-MariaDB
-- Versión de PHP: 7.4.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ss_cms`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE PROCEDURE `CategoriesCms_Get` ()  BEGIN

SELECT
cms_categories.category_id AS id,
cms_categories.category_name AS _name
FROM cms_categories;

END$$

CREATE PROCEDURE `Contact_Add` (IN `CNAME` VARCHAR(100), IN `CLASTNAME` VARCHAR(100), IN `CEMAIL` VARCHAR(500), IN `CCOMMENT` VARCHAR(8000))  BEGIN

INSERT INTO contact
(`contact_name`,
`contact_lastname`,
`contact_email`,
`contact_comments`)
VALUES
(CNAME,
CLASTNAME,
CEMAIL,
CCOMMENT);


END$$

CREATE PROCEDURE `Contact_Get` ()  BEGIN

SELECT contact.contact_id,
    contact.contact_name,
    contact.contact_lastname,
    contact.contact_email,
    contact.contact_comments,
    states.state_id,
    states.state_name,
    states_type.type_id,
    states_type.type_name
FROM contact
INNER JOIN states ON states.state_id = contact.state_id
INNER JOIN states_type ON states_type.type_id = states.state_type
WHERE states.state_id = 3 OR states.state_id = 4;

END$$

CREATE PROCEDURE `Contact_GetXId` (IN `CID` INT)  BEGIN

SELECT contact.contact_id,
    contact.contact_name,
    contact.contact_lastname,
    contact.contact_email,
    contact.contact_comments,
    states.state_id,
    states.state_name,
    states_type.type_id,
    states_type.type_name
FROM contact
INNER JOIN states ON states.state_id = contact.state_id
INNER JOIN states_type ON states_type.type_id = states.state_type
WHERE contact.contact_id = CID;

END$$

CREATE PROCEDURE `Contact_Update` (IN `CID` INT, IN `CSTATEID` INT, IN `CRESPONSE` VARCHAR(8000))  BEGIN

UPDATE contact
SET
contact.state_id = CSTATEID,
contact_response = CRESPONSE
WHERE contact_id = CID;

END$$

CREATE PROCEDURE `ContentCms_Add` (IN `TITLE` VARCHAR(200), IN `CONTENT` VARCHAR(5600), IN `ADITIONALINFO` VARCHAR(1000), IN `EXTRAINFO` VARCHAR(1000), IN `CPATH` VARCHAR(100), IN `CDATE` DATETIME, IN `TCONTENT` INT, IN `CSECTION` INT, IN `CHIERARCHY` INT, IN `CSTATE` INT, IN `CENVIROMENT` INT, IN `CCATEGORY` INT)  BEGIN

SET @IDENTIFIER = uuid();

INSERT INTO cms_content
(cms_content.content_title,
cms_content.content_text,
cms_content.content_aditionalinfo,
cms_content.content_extrainfo,
cms_content.content_path,
cms_content.content_date,
cms_content.type_id,
cms_content.section_id,
cms_content.content_hierarchy,
cms_content.state_id,
cms_content.enviroment_id,
cms_content.category_id,
cms_content.content_identifier)
VALUES
(TITLE,
CONTENT,
ADITIONALINFO,
EXTRAINFO,
CPATH,
CDATE,
TCONTENT,
CSECTION,
CHIERARCHY, 
CSTATE,
CENVIROMENT,
CCATEGORY,
@IDENTIFIER);

SELECT
*
FROM
cms_content
WHERE
cms_content.content_identifier = @IDENTIFIER;

END$$

CREATE PROCEDURE `ContentCms_Delete` (IN `IDENTIFIER` VARCHAR(100))  BEGIN

DELETE FROM
cms_files
WHERE
cms_files.content_identifier = IDENTIFIER;

DELETE FROM cms_content
WHERE cms_content.content_identifier = IDENTIFIER;

END$$

CREATE PROCEDURE `ContentCms_Get` ()  BEGIN

SELECT
cms_content.content_id,
cms_content.content_title,
cms_content.content_text,
cms_content.content_aditionalinfo,
cms_content.content_extrainfo,
cms_content.content_path,
date(cms_content.content_date) as content_date,
cms_content.type_id,
cms_contenttype.type_name,
cms_content.section_id,
cms_section.section_name,
cms_content.content_hierarchy,
cms_content.state_id,
states.state_name,
cms_content.enviroment_id,
cms_enviroment.enviroment_name,
cms_content.category_id,
cms_categories.category_name,
cms_content.content_identifier
FROM
cms_content
INNER JOIN cms_contenttype ON cms_contenttype.type_id = cms_content.type_id
INNER JOIN cms_section ON cms_section.section_id = cms_content.section_id
INNER JOIN states ON states.state_id = cms_content.state_id
INNER JOIN cms_enviroment on cms_enviroment.enviroment_id = cms_content.enviroment_id
INNER JOIN cms_categories ON cms_categories.category_id = cms_content.category_id;

END$$

CREATE PROCEDURE `ContentCms_GetXCategory` (IN `CATEGORY` INT)  BEGIN

SELECT
cms_content.content_id,
cms_content.content_title,
cms_content.content_text,
cms_content.content_aditionalinfo,
cms_content.content_extrainfo,
cms_content.content_path,
date(cms_content.content_date) as content_date,
cms_content.type_id,
cms_contenttype.type_name,
cms_content.section_id,
cms_section.section_name,
cms_content.content_hierarchy,
cms_content.state_id,
states.state_name,
cms_content.enviroment_id,
cms_enviroment.enviroment_name,
cms_content.category_id,
cms_categories.category_name
FROM
cms_content
INNER JOIN cms_contenttype ON cms_contenttype.type_id = cms_content.type_id
INNER JOIN cms_section ON cms_section.section_id = cms_content.section_id
INNER JOIN states ON states.state_id = cms_content.state_id
INNER JOIN cms_enviroment on cms_enviroment.enviroment_id = cms_content.enviroment_id
INNER JOIN cms_categories ON cms_categories.category_id = cms_content.category_id
WHERE cms_content.category_id= CATEGORY;

END$$

CREATE PROCEDURE `ContentCms_GetXId` (IN `ID` INT)  BEGIN

SELECT
cms_content.content_id,
cms_content.content_title,
cms_content.content_text,
cms_content.content_aditionalinfo,
cms_content.content_extrainfo,
cms_content.content_path,
date(cms_content.content_date) as content_date,
cms_content.type_id,
cms_contenttype.type_name,
cms_content.section_id,
cms_section.section_name,
cms_content.content_hierarchy,
cms_content.state_id,
states.state_name,
cms_content.enviroment_id,
cms_enviroment.enviroment_name,
cms_content.category_id,
cms_categories.category_name
FROM
cms_content
INNER JOIN cms_contenttype ON cms_contenttype.type_id = cms_content.type_id
INNER JOIN cms_section ON cms_section.section_id = cms_content.section_id
INNER JOIN states ON states.state_id = cms_content.state_id
INNER JOIN cms_enviroment on cms_enviroment.enviroment_id = cms_content.enviroment_id
INNER JOIN cms_categories ON cms_categories.category_id = cms_content.category_id
WHERE cms_content.content_id = ID;

END$$

CREATE PROCEDURE `ContentCms_GetXSection` (IN `SECTION` INT)  BEGIN

SELECT
cms_content.content_id,
cms_content.content_title,
cms_content.content_text,
cms_content.content_aditionalinfo,
cms_content.content_extrainfo,
cms_content.content_path,
date(cms_content.content_date) as content_date,
cms_content.type_id,
cms_contenttype.type_name,
cms_content.section_id,
cms_section.section_name,
cms_content.content_hierarchy,
cms_content.state_id,
states.state_name,
cms_content.enviroment_id,
cms_enviroment.enviroment_name,
cms_content.category_id,
cms_categories.category_name
FROM
cms_content
INNER JOIN cms_contenttype ON cms_contenttype.type_id = cms_content.type_id
INNER JOIN cms_section ON cms_section.section_id = cms_content.section_id
INNER JOIN states ON states.state_id = cms_content.state_id
INNER JOIN cms_enviroment on cms_enviroment.enviroment_id = cms_content.enviroment_id
INNER JOIN cms_categories ON cms_categories.category_id = cms_content.category_id
WHERE cms_content.section_id = SECTION;

END$$

CREATE PROCEDURE `ContentCms_GetXTContent` (IN `TCONTENT` INT)  BEGIN

SELECT
cms_content.content_id,
cms_content.content_title,
cms_content.content_text,
cms_content.content_aditionalinfo,
cms_content.content_extrainfo,
cms_content.content_path,
date(cms_content.content_date) as content_date,
cms_content.type_id,
cms_contenttype.type_name,
cms_content.section_id,
cms_section.section_name,
cms_content.content_hierarchy,
cms_content.state_id,
states.state_name,
cms_content.enviroment_id,
cms_enviroment.enviroment_name,
cms_content.category_id,
cms_categories.category_name,
cms_content.content_identifier
FROM
cms_content
INNER JOIN cms_contenttype ON cms_contenttype.type_id = cms_content.type_id
INNER JOIN cms_section ON cms_section.section_id = cms_content.section_id
INNER JOIN states ON states.state_id = cms_content.state_id
INNER JOIN cms_enviroment on cms_enviroment.enviroment_id = cms_content.enviroment_id
INNER JOIN cms_categories ON cms_categories.category_id = cms_content.category_id
WHERE cms_content.type_id = TCONTENT;

END$$

CREATE PROCEDURE `ContentCms_Update` (IN `ID` INT, IN `TITLE` VARCHAR(200), IN `CONTENT` VARCHAR(5600), IN `ADITIONALINFO` VARCHAR(1000), IN `EXTRAINFO` VARCHAR(1000), IN `CPATH` VARCHAR(100), IN `CDATE` DATETIME, IN `TCONTENT` INT, IN `SECTION` INT, IN `HIERARCHY` INT, IN `CSTATE` INT, IN `ENVIROMENT` INT, IN `CATEGOTY` INT)  BEGIN

UPDATE cms_content
SET
content_title = TITLE,
content_text = CONTENT,
content_aditionalinfo = ADITIONALINFO,
content_extrainfo = EXTRAINFO,
content_path = CPATH,
content_date = CDATE,
type_id = TCONTENT,
section_id = SECTION,
content_hierarchy = HIERARCHY,
state_id = CSTATE,
enviroment_id = ENVIROMENT,
category_id = CATEGOTY
WHERE content_id = ID;


END$$

CREATE PROCEDURE `ContentPage_Get` (IN `TCONTENT` INT, IN `SECTION` INT, IN `ENVIROMENT` INT)  BEGIN

SELECT
cms_content.content_id,
cms_content.content_title,
cms_content.content_text,
cms_content.content_aditionalinfo,
cms_content.content_extrainfo,
cms_content.content_path,
date(cms_content.content_date) as content_date,
cms_content.type_id,
cms_contenttype.type_name,
cms_content.section_id,
cms_section.section_name,
cms_content.content_hierarchy,
cms_content.state_id,
states.state_name,
cms_content.enviroment_id,
cms_enviroment.enviroment_name,
cms_content.category_id,
cms_categories.category_name,
cms_content.content_identifier
FROM
cms_content
INNER JOIN cms_contenttype ON cms_contenttype.type_id = cms_content.type_id
INNER JOIN cms_section ON cms_section.section_id = cms_content.section_id
INNER JOIN states ON states.state_id = cms_content.state_id
INNER JOIN cms_enviroment on cms_enviroment.enviroment_id = cms_content.enviroment_id
INNER JOIN cms_categories ON cms_categories.category_id = cms_content.category_id
WHERE cms_content.type_id = TCONTENT
AND cms_content.section_id = SECTION
AND (cms_content.enviroment_id = ENVIROMENT OR cms_content.enviroment_id = 3)
AND cms_content.state_id = 1;

END$$

CREATE PROCEDURE `ContentTypeCms_Add` (IN `TNAME` VARCHAR(100), IN `TSHOW` INT)  BEGIN

INSERT INTO cms_contenttype
(type_name,
type_show)
VALUES
(TNAME,
TSHOW);
##WHERE cms_contenttype.type_id = ID;

END$$

CREATE PROCEDURE `ContentTypeCms_Delete` (IN `ID` INT)  BEGIN

DELETE FROM cms_content
WHERE cms_content.type_id = ID;

DELETE FROM cms_contenttype
WHERE cms_contenttype.type_id = ID;

END$$

CREATE PROCEDURE `ContentTypeCms_Get` ()  BEGIN

SELECT
cms_contenttype.type_id AS id,
cms_contenttype.type_name AS _name
FROM cms_contenttype
WHERE type_show = 1;

END$$

CREATE PROCEDURE `ContentTypeCms_GetAll` ()  BEGIN

SELECT cms_contenttype.type_id,
    cms_contenttype.type_name,
    cms_contenttype.type_show
FROM cms_contenttype;
##WHERE type_show = 1;

END$$

CREATE PROCEDURE `ContentTypeCms_GetXId` (IN `ID` INT)  BEGIN

SELECT cms_contenttype.type_id,
    cms_contenttype.type_name,
    cms_contenttype.type_show
FROM cms_contenttype
WHERE cms_contenttype.type_id = ID;

END$$

CREATE PROCEDURE `ContentTypeCms_Update` (IN `ID` INT, IN `TNAME` VARCHAR(100), IN `TSHOW` INT)  BEGIN

UPDATE cms_contenttype
SET
type_name = TNAME,
type_show = TSHOW
WHERE cms_contenttype.type_id = ID;

END$$

CREATE PROCEDURE `Enviroment_Get` ()  BEGIN

SELECT
cms_enviroment.enviroment_id AS id,
cms_enviroment.enviroment_name AS _name
FROM cms_enviroment;


END$$

CREATE PROCEDURE `FilesCms_Add` (IN `FPATH` VARCHAR(1000), IN `FPOSITION` INT, IN `CIDENTIFIER` VARCHAR(100))  BEGIN

INSERT INTO cms_files
(file_path,
file_position,
content_identifier)
VALUES
(FPATH,
FPOSITION,
CIDENTIFIER);

END$$

CREATE PROCEDURE `FilesCms_Delete` (IN `IDENTIFIER` INT)  BEGIN

DELETE FROM cms_files
WHERE
cms_files.content_identifier = IDENTIFIER;

END$$

CREATE PROCEDURE `FilesCms_Get` ()  BEGIN

SELECT cms_files.file_id,
    cms_files.file_path,
    cms_files.file_position,
    cms_files.content_identifier,
    cms_content.content_title,
    cms_content.state_id,
    states.state_name
FROM cms_files
INNER JOIN cms_content ON cms_content.content_identifier = cms_files.content_identifier
INNER JOIN states on states.state_id = cms_content.state_id
ORDER BY cms_files.file_id ASC;

END$$

CREATE PROCEDURE `FilesCms_GetXContent` (IN `ID` INT)  BEGIN

SELECT cms_files.file_id,
    cms_files.file_path,
    cms_files.file_position,
    cms_files.content_identifier,
    cms_content.content_title,
    cms_content.state_id,
    states.state_name
FROM cms_files
INNER JOIN cms_content ON cms_content.content_identifier = cms_files.content_identifier
INNER JOIN states on states.state_id = cms_content.state_id
WHERE cms_content.content_id = ID
ORDER BY cms_files.file_id ASC;

END$$

CREATE PROCEDURE `FilesCms_GetXId` (IN `ID` INT)  BEGIN

SELECT cms_files.file_id,
    cms_files.file_path,
    cms_files.file_position,
    cms_files.content_identifier,
    cms_content.content_title,
    cms_content.state_id,
    states.state_name
FROM cms_files
INNER JOIN cms_content ON cms_content.content_identifier = cms_files.content_identifier
INNER JOIN states on states.state_id = cms_content.state_id
WHERE cms_files.file_id = ID
ORDER BY cms_files.file_id ASC;

END$$

CREATE PROCEDURE `SectionsCms_Add` (IN `SNAME` VARCHAR(100))  BEGIN

INSERT INTO cms_section
(section_name)
VALUES
(SNAME);

END$$

CREATE PROCEDURE `SectionsCms_Delete` (IN `ID` INT)  BEGIN

DELETE FROM cms_section
WHERE cms_section.section_id = ID;

END$$

CREATE PROCEDURE `SectionsCms_Get` ()  BEGIN

SELECT cms_section.section_id AS id,
    cms_section.section_name AS _name
FROM cms_section;

END$$

CREATE PROCEDURE `states_Get` ()  BEGIN

SELECT
states.state_id AS id,
states.state_name as _name
FROM `states`
INNER JOIN states_type on states_type.type_id = states.state_type;

END$$

CREATE PROCEDURE `states_GetXType` (IN `ID` INT)  BEGIN

SELECT *
FROM states
INNER JOIN states_type on states_type.type_id = states.state_type
WHERE states_type.type_id = ID;

END$$

CREATE PROCEDURE `Tokens_Get` (IN `IP` VARCHAR(45), IN `SO` VARCHAR(200), IN `BROWSER` VARCHAR(200), IN `USER` VARCHAR(45), IN `TDATE` DATETIME)  BEGIN

DECLARE CANT INT;
DECLARE US DOUBLE;

SET @IP = IP;
SET @SO = SO;
SET @BROWSER = BROWSER;
SET @USER = USER;
SET @FECHA = TDATE;
SET @EXPIRA = concat(date(TDATE), ' 23:59:00');
SET @HASHTXT = SHA2(concat(@IP, @SO, @BROWSER, @USER, @FECHA, @EXPIRA, uuid()), 224);

SELECT
COUNT(tokens.token_user),
tokens.token_user
into
CANT,
US
FROM
tokens
WHERE tokens.token_user = @USER
limit 1;

IF CANT > 0 THEN

UPDATE tokens
SET
tokens.token_hash = @HASHTXT,
tokens.token_ip = @IP,
tokens.token_so = @SO,
tokens.token_browser = @BROWSER,
tokens.token_date = @FECHA,
tokens.token_expires = @EXPIRA,
tokens.state_id = 1
WHERE tokens.token_user = @USER;

else

INSERT INTO tokens
(tokens.token_hash,
tokens.token_ip,
tokens.token_so,
tokens.token_browser,
tokens.token_user,
tokens.token_date,
tokens.token_expires,
tokens.state_id)
VALUES
(
@HASHTXT,
@IP,
@SO,
@BROWSER,
@USER,
@FECHA,
@EXPIRA,
1
);
end if;

SELECT
tokens.token_hash as token
FROM
tokens
WHERE
tokens.token_hash = @HASHTXT;

END$$

CREATE PROCEDURE `Tokens_GetState` (IN `TOKEN` VARCHAR(5000), IN `TDATE` DATETIME)  BEGIN

DECLARE CONT INT;
DECLARE CREATION DATETIME;
DECLARE EXPIRATION DATETIME;

SELECT COUNT(tokens.token_hash),
    tokens.token_date,
    tokens.token_expires
    INTO
    CONT,
    CREATION,
    EXPIRATION
FROM tokens
where tokens.token_hash = TOKEN;

IF CONT > 0 then

IF TOKEN = 'PAGE6d989d57-501e-11ea-9c91-28d2448f5d1e' THEN

SELECT 1 as STATE, 'OK' as RESULT;

ELSE

IF DATE(CREATION) = DATE(TDATE) THEN
   IF (HOUR(TDATE) - HOUR(CREATION)) <= 5 THEN
       UPDATE tokens
       SET
       tokens.token_date = TDATE,
       state_id = 1
	    WHERE tokens.token_hash = TOKEN;
       SELECT 1 as STATE, 'OK' as RESULT;
   ELSE
       UPDATE tokens
       SET
       tokens.state_id = 2
	    WHERE tokens.token_hash = TOKEN;
       select 2 as STATE, 'EXPIRED' as RESULT;
   END IF;
ELSE
 UPDATE tokens
       SET
       tokens.state_id = 2
	    WHERE tokens.token_hash = TOKEN;
       select 2 as STATE, 'EXPIRED' as RESULT;
END IF;

END IF; 

ELSE

SELECT 0 AS STATE, 'NO RESULTS' AS RESULT;

END IF;
 

END$$

CREATE PROCEDURE `Users_Add` (IN `names` VARCHAR(100), IN `lstname` VARCHAR(100), IN `tel` VARCHAR(10), IN `email` VARCHAR(500), IN `pass` VARCHAR(45), IN `type` INT, IN `state` INT)  BEGIN

declare scount int;
declare userid int;
DECLARE SCOUNTIN INT;

select 
count(users.user_id),
ifnull(users.user_id, 0)
into
scount,
userid
from users
where users.user_email = email;

if scount > 0 then

SELECT
'0' AS RESPONSEID,
'USUARIO YA EXISTE' AS RESPONSETXT;

else

INSERT INTO
users
(users.user_name,
users.user_lstname,
users.user_tel,
users.user_email,
users.user_password,
users.user_type,
users.user_state)
values
(names,
lstname,
tel,
email,
MD5(pass),
type,
state);

SELECT
ROW_COUNT()
INTO
SCOUNTIN;

IF SCOUNTIN > 0 THEN

SELECT
users.*
FROM
users
WHERE
users.user_email = email;

ELSE
SELECT
'0' AS RESPONSEID,
'ERROR AL REGISTRAR LA INFORMACIÓN' AS RESPONSETXT;
END IF;

end if;
END$$

CREATE PROCEDURE `Users_Delete` (IN `id` INT)  BEGIN

DELETE FROM users
WHERE users.user_id = id;

END$$

CREATE PROCEDURE `Users_Get` (IN `IDUSER` INT)  BEGIN

DECLARE USERTYPE INT;

SELECT
users.user_type
INTO
USERTYPE
FROM
users
WHERE
users.user_id = IDUSER;

IF USERTYPE = 1 THEN
select
users.user_id,
users.user_name,
users.user_lstname,
users.user_tel,
users.user_email,
users_type.type_name,
users.user_type,
states.state_name
from
users
inner join users_type on users_type.type_id = users.user_type
inner join states on states.state_id = users.user_state
order by users.user_id asc;
END IF;

IF USERTYPE = 2 THEN
select
users.user_id,
users.user_name,
users.user_lstname,
users.user_tel,
users.user_email,
users_type.type_name,
users.user_type,
states.state_name
from
users
inner join users_type on users_type.type_id = users.user_type
inner join states on states.state_id = users.user_state
WHERE users.user_type > 1
order by users.user_id asc;
END IF;

IF USERTYPE = 3 THEN
select
"0" AS user_id,
"0" AS user_name,
"0" AS user_lstname,
"0" AS user_tel,
"0" AS user_email,
"0" AS type_name,
"0" AS user_type,
"0" AS state_name;

END IF;

END$$

CREATE PROCEDURE `Users_GetXId` (IN `id` INT)  BEGIN

SELECT users.user_id,
    users.user_name,
    users.user_lstname,
    users.user_tel,
    users.user_email,
    users.user_password,
    users.user_type,
    users.user_state
FROM users
inner join users_type on users_type.type_id = users.user_type
inner join states on states.state_id = users.user_state
where users.user_id = id;

END$$

CREATE PROCEDURE `Users_Login` (IN `TUSER` VARCHAR(500), IN `UPASS` VARCHAR(100))  BEGIN

DECLARE COUNTER INT;
DECLARE USTATE INT;

SELECT
COUNT(users.user_id),
users.user_state
INTO 
COUNTER, 
USTATE
FROM users
where (users.user_email = TUSER or users.user_tel = TUSER)
and users.user_password = UPASS;

IF COUNTER > 0 THEN
 IF USTATE = 1 THEN
  SELECT
    '1' AS RESPONSEID,
    'OK' AS RESPONSETXT,
    users.user_id,
    users.user_name,
    users.user_lstname,
    users.user_tel,
    users.user_email,
    users.user_type,
    users_type.type_name,
    users.user_state
  FROM users
  inner join users_type on users_type.type_id = users.user_type
  inner join states on states.state_id = users.user_state
  where (users.user_email = TUSER or users.user_tel = TUSER)
  and users.user_password = UPASS
  and users.user_state = 1;
 ELSE
  SELECT
  '0' AS RESPONSEID,
  'USUARIO INACTIVO' AS RESPONSETXT;
 END IF;
ELSE
  SELECT
  '0' AS RESPONSEID,
  'ERROR DE AUTENTICACIÓN' AS RESPONSETXT;
END IF;
END$$

CREATE PROCEDURE `Users_Update` (IN `id` INT, IN `names` VARCHAR(100), IN `lstname` VARCHAR(100), IN `tel` VARCHAR(10), IN `email` VARCHAR(500), IN `pass` VARCHAR(45), IN `passval` INT, IN `type` INT, IN `state` INT)  BEGIN

DECLARE SCOUNTIN INT;

IF passval = 1 THEN 

UPDATE users
SET 
user_name = names,
user_lstname = lstname,
user_tel = tel,
user_email = email,
user_password = MD5(pass),
user_type = type,
user_state = state
WHERE user_id = id;

SELECT
ROW_COUNT()
INTO
SCOUNTIN;

IF SCOUNTIN > 0 THEN

SELECT
users.*
FROM
users
WHERE
user_id = id;

ELSE
SELECT
'0' AS RESPONSEID,
'ERROR AL REGISTRAR LA INFORMACIÓN' AS RESPONSETXT;
END IF;

ELSE

UPDATE users
SET 
user_name = names,
user_lstname = lstname,
user_tel = tel,
user_email = email,
user_password = pass,
user_type = type,
user_state = state
WHERE user_id = id;

SELECT
ROW_COUNT()
INTO
SCOUNTIN;

IF SCOUNTIN > 0 THEN

SELECT
users.*
FROM
users
WHERE
user_id = id;

ELSE
SELECT
'0' AS RESPONSEID,
'ERROR AL REGISTRAR LA INFORMACIÓN' AS RESPONSETXT;
END IF;

END IF;

END$$

CREATE PROCEDURE `UserType_Get` ()  BEGIN

SELECT
users_type.type_id AS  id,
users_type.type_name AS _name
FROM users_type
ORDER BY users_type.type_name ASC;

END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_categories`
--

CREATE TABLE `cms_categories` (
  `category_id` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cms_categories`
--

INSERT INTO `cms_categories` (`category_id`, `category_name`) VALUES
(1, 'Imagenes'),
(2, 'Información'),
(3, 'Todos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_content`
--

CREATE TABLE `cms_content` (
  `content_id` int(11) NOT NULL,
  `content_title` varchar(200) DEFAULT NULL,
  `content_text` varchar(5600) DEFAULT NULL,
  `content_aditionalinfo` varchar(1000) NOT NULL,
  `content_extrainfo` varchar(1000) DEFAULT NULL,
  `content_path` varchar(100) DEFAULT NULL,
  `content_date` datetime DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `section_id` int(11) DEFAULT NULL,
  `content_hierarchy` int(11) DEFAULT NULL,
  `state_id` int(11) DEFAULT NULL,
  `enviroment_id` int(11) DEFAULT 1,
  `category_id` int(11) DEFAULT NULL,
  `content_identifier` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cms_content`
--

INSERT INTO `cms_content` (`content_id`, `content_title`, `content_text`, `content_aditionalinfo`, `content_extrainfo`, `content_path`, `content_date`, `type_id`, `section_id`, `content_hierarchy`, `state_id`, `enviroment_id`, `category_id`, `content_identifier`) VALUES
(30, 'ba', 'N/A', '#', 'N/A', '2020_05_26t1s1e1c1id5ecc75a6ef82e.jpg', '2020-05-26 01:49:56', 1, 1, 1, 1, 3, 1, '5a555d25-9ec6-11ea-aa54-3c91806ad686'),
(31, 'Shake It Milkshakes & Smoothie Bar', '27 De Abril De 2016', 'https://shakeitcol.co/HomeShake/inicio.html', 'N/A', '2020_05_25t2s1e3c1id5ecc3c5706f3f.png', '2020-05-25 21:48:40', 2, 1, 1, 1, 3, 1, 'f8a73217-9ed0-11ea-aa54-3c91806ad686'),
(32, 'Friki Festival Valledupar', '25 De Agosto De 2018', 'http://frikifestivalvalledupar.com', '', '2020_05_25t2s1e3c1id5ecc48590e912.png', '2020-05-25 22:56:19', 2, 1, 2, 1, 3, 1, '20eb1a36-9ed8-11ea-aa54-3c91806ad686'),
(33, 'Wilfrifdo González Escritor', '22 De Junio De 2020', 'http://wilfridogonzalezescritor.com/', '', '2020_05_25t2s1e3c1id5ecc4940c9f9b.png', '2020-05-25 22:57:26', 2, 1, 3, 1, 3, 1, 'ab106374-9ed8-11ea-aa54-3c91806ad686');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_contenttype`
--

CREATE TABLE `cms_contenttype` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(100) NOT NULL,
  `type_show` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cms_contenttype`
--

INSERT INTO `cms_contenttype` (`type_id`, `type_name`, `type_show`) VALUES
(1, 'Banners', 1),
(2, 'Proyectos', 1),
(3, 'Contacto', 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_enviroment`
--

CREATE TABLE `cms_enviroment` (
  `enviroment_id` int(11) NOT NULL,
  `enviroment_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cms_enviroment`
--

INSERT INTO `cms_enviroment` (`enviroment_id`, `enviroment_name`) VALUES
(1, 'Web'),
(2, 'Móvil'),
(3, 'Todos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_files`
--

CREATE TABLE `cms_files` (
  `file_id` int(11) NOT NULL,
  `file_path` varchar(1000) NOT NULL,
  `file_position` int(11) NOT NULL,
  `content_identifier` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cms_section`
--

CREATE TABLE `cms_section` (
  `section_id` int(11) NOT NULL,
  `section_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `cms_section`
--

INSERT INTO `cms_section` (`section_id`, `section_name`) VALUES
(1, 'Principal');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `contact`
--

CREATE TABLE `contact` (
  `contact_id` int(11) NOT NULL,
  `contact_name` varchar(100) DEFAULT NULL,
  `contact_lastname` varchar(100) DEFAULT NULL,
  `contact_email` varchar(500) DEFAULT NULL,
  `contact_comments` varchar(8000) DEFAULT NULL,
  `state_id` int(11) DEFAULT 3,
  `contact_response` varchar(8000) DEFAULT 'N/A'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `contact`
--

INSERT INTO `contact` (`contact_id`, `contact_name`, `contact_lastname`, `contact_email`, `contact_comments`, `state_id`, `contact_response`) VALUES
(1, 'Andrés', 'Estrada', 'afestradam@gmail.com', 'huiigjgjghjfhfhfhg', 4, ''),
(2, 'bjb', 'klnkl', 'afestradam@gmail.com', 'kgfycvnklnnk cajh ckc cd ckleck ecew vslkvnw', 3, 'N/A');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `states`
--

CREATE TABLE `states` (
  `state_id` int(11) NOT NULL,
  `state_name` varchar(45) DEFAULT NULL,
  `state_type` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `states`
--

INSERT INTO `states` (`state_id`, `state_name`, `state_type`) VALUES
(1, 'Activo', 1),
(2, 'Inactivo', 1),
(3, 'Sin revisar', 2),
(4, 'Revisado-Sin responder', 2),
(5, 'Comentario Inapropiado', 2),
(6, 'Respuesta Enviada', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `states_type`
--

CREATE TABLE `states_type` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `states_type`
--

INSERT INTO `states_type` (`type_id`, `type_name`) VALUES
(1, 'Tipo'),
(2, 'Contacto');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tokens`
--

CREATE TABLE `tokens` (
  `token_id` int(11) NOT NULL,
  `token_hash` varchar(5000) NOT NULL,
  `token_ip` varchar(45) NOT NULL,
  `token_so` varchar(200) NOT NULL,
  `token_browser` varchar(200) NOT NULL,
  `token_user` varchar(45) NOT NULL,
  `token_date` datetime NOT NULL,
  `token_expires` datetime NOT NULL,
  `state_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tokens`
--

INSERT INTO `tokens` (`token_id`, `token_hash`, `token_ip`, `token_so`, `token_browser`, `token_user`, `token_date`, `token_expires`, `state_id`) VALUES
(1, '1f5568999a1774042346af26757a6d82fb5dd05c6a6f6f03a352d24e', '::1', 'Unknown OS Platform', 'Unknown Browser', '1', '2020-05-25 23:19:02', '2020-05-25 23:59:00', 2),
(2, 'A2A7E240SOFTAN-33F7SOL-4DD2-9C34-49270B9F945E', 'public', '-', '-', 'webPage', '2020-02-15 17:20:47', '2099-02-15 23:59:00', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_lstname` varchar(100) DEFAULT NULL,
  `user_tel` varchar(10) DEFAULT NULL,
  `user_email` varchar(500) DEFAULT NULL,
  `user_password` varchar(100) DEFAULT NULL,
  `user_type` int(11) DEFAULT NULL,
  `user_state` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_lstname`, `user_tel`, `user_email`, `user_password`, `user_type`, `user_state`) VALUES
(1, 'Andrés', 'Estrada', '3175025547', 'afestradam@gmail.com', '299e45bd147f472612056dd3154c8988', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_info`
--

CREATE TABLE `users_info` (
  `info_id` int(11) NOT NULL,
  `user_terms` int(11) DEFAULT NULL,
  `user_advertising` int(11) DEFAULT NULL,
  `user_photo` varchar(100) DEFAULT NULL,
  `user_identification` varchar(100) DEFAULT NULL,
  `identification_type` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users_type`
--

CREATE TABLE `users_type` (
  `type_id` int(11) NOT NULL,
  `type_name` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `users_type`
--

INSERT INTO `users_type` (`type_id`, `type_name`) VALUES
(1, 'SuperAdmin'),
(2, 'Administrador'),
(3, 'Regular');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `cms_categories`
--
ALTER TABLE `cms_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indices de la tabla `cms_content`
--
ALTER TABLE `cms_content`
  ADD PRIMARY KEY (`content_id`);

--
-- Indices de la tabla `cms_contenttype`
--
ALTER TABLE `cms_contenttype`
  ADD PRIMARY KEY (`type_id`);

--
-- Indices de la tabla `cms_enviroment`
--
ALTER TABLE `cms_enviroment`
  ADD PRIMARY KEY (`enviroment_id`);

--
-- Indices de la tabla `cms_files`
--
ALTER TABLE `cms_files`
  ADD PRIMARY KEY (`file_id`);

--
-- Indices de la tabla `cms_section`
--
ALTER TABLE `cms_section`
  ADD PRIMARY KEY (`section_id`);

--
-- Indices de la tabla `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indices de la tabla `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`state_id`);

--
-- Indices de la tabla `states_type`
--
ALTER TABLE `states_type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indices de la tabla `tokens`
--
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`token_id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indices de la tabla `users_info`
--
ALTER TABLE `users_info`
  ADD PRIMARY KEY (`info_id`);

--
-- Indices de la tabla `users_type`
--
ALTER TABLE `users_type`
  ADD PRIMARY KEY (`type_id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cms_categories`
--
ALTER TABLE `cms_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `cms_content`
--
ALTER TABLE `cms_content`
  MODIFY `content_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT de la tabla `cms_contenttype`
--
ALTER TABLE `cms_contenttype`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `cms_enviroment`
--
ALTER TABLE `cms_enviroment`
  MODIFY `enviroment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `cms_files`
--
ALTER TABLE `cms_files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `cms_section`
--
ALTER TABLE `cms_section`
  MODIFY `section_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `contact`
--
ALTER TABLE `contact`
  MODIFY `contact_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `states`
--
ALTER TABLE `states`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `states_type`
--
ALTER TABLE `states_type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tokens`
--
ALTER TABLE `tokens`
  MODIFY `token_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `users_info`
--
ALTER TABLE `users_info`
  MODIFY `info_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users_type`
--
ALTER TABLE `users_type`
  MODIFY `type_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
