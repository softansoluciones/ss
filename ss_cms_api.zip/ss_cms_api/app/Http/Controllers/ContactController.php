<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\TokensController;
use App\Http\Controllers\EmailController;
use DB;

class ContactController extends Controller {

    public function get_Contacts(Request $request) {

        $token_in = $request->header('authtoken');
        $contact__id = $request->header('contact_id');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {
            $contact = DB::select("CALL Contact_Get();");
            $rows = count($contact);
            if ($rows > 0) {
                return response()->json(["Response" => $contact, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function get_Contact($id, Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $contact = DB::select("call Contact_GetXId('$id');");

            $rows = count($contact);

            if ($rows > 0) {
                return response()->json(["Response" => $contact, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function insert_Contact(Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = true; //Se deja en true para no cambiar toda la estructura.

        if ($authorization == true) {

            $NAME = $request->contact_name;
            $LASTNAME = $request->contact_lastname;
            $EMAIL = $request->contact_email;
            $COMMENT = $request->contact_comment;

            $contact = DB::insert("CALL Contact_Add('$NAME', '$LASTNAME', '$EMAIL', '$COMMENT');");
            if ($contact) {
                return response()->json(["Response" => 1, "Message" => "Information registered successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error registering information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function update_Contact(Request $request) {
        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $mailing = new EmailController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $ID = $request->contact_id;
            $NAME = $request->contact_name;
            $LASTNAME = $request->contact_lastname;
            $EMAIL = $request->contact_email;
            $STATE = $request->contact_state;
            $RESPONSE = $request->contact_response;

            $contact = DB::update("CALL Contact_Update('$ID', '$STATE', '$RESPONSE');");
            if ($contact) {
                if ($STATE == 6) {
                    $mailing->EmailContact($NAME, $EMAIL, $RESPONSE);
                }
                return response()->json(["Response" => 1, "Message" => "Information registered successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error registering information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

}
