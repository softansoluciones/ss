<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\TokensController;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Storage;
use DB;


class ContentController extends Controller {

    public function get_Content(Request $request) {

        $token_in = $request->header('authtoken');
        $user__id = $request->header('user_id');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {
            $Content = DB::select("CALL ContentCms_Get();");
            $rows = count($Content);
            if ($rows > 0) {
                return response()->json(["Response" => $Content, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function get_ContentXId($id, Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $Content = DB::select("call ContentCms_GetXId('$id');");

            $rows = count($Content);

            if ($rows > 0) {
                return response()->json(["Response" => $Content, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function get_ContentXCategory($id, Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $Content = DB::select("call ContentCms_GetXCategory('$id');");

            $rows = count($Content);

            if ($rows > 0) {
                return response()->json(["Response" => $Content, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function get_ContentXSection($id, Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $Content = DB::select("call ContentCms_GetXSection('$id');");

            $rows = count($Content);

            if ($rows > 0) {
                return response()->json(["Response" => $Content, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function get_ContentXTContent($id, Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $Content = DB::select("call ContentCms_GetXTContent('$id');");

            $rows = count($Content);

            if ($rows > 0) {
                return response()->json(["Response" => $Content, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function insert_Content(Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $TITLE = $request->content_title;
            $CONTENT = $request->content_data;
            $ADITIONAL = $request->content_aditional;
            $DATE = date("Y-m-d H:i:s");
            $TYPE = $request->content_type;
            $SECTION = $request->content_section;
            $HIERARCHY = $request->content_hierarchy;
            $STATE = $request->content_state;
            $ENVIROMENT = $request->content_environment;
            $CATEGORY = $request->content_category;
            if($request->hasFile('content_path')){
                $PATH = $this->save_File($request->content_path, $TYPE, $SECTION, $ENVIROMENT, $CATEGORY);
            }else{
                $PATH = $request->content_path;
            }
            if($request->hasFile('content_extra')){
                $EXTRA = $this->save_File($request->content_extra, $TYPE, $SECTION, $ENVIROMENT, $CATEGORY);
            }else{
                $EXTRA = $request->content_extra;
            }

            $Content = DB::select("CALL ContentCms_Add('$TITLE', '$CONTENT', '$ADITIONAL', '$EXTRA', '$PATH', '$DATE', '$TYPE', '$SECTION', '$HIERARCHY', '$STATE', '$ENVIROMENT', '$CATEGORY');");
            $rows = count($Content);
            if ($rows > 0) {
                return response()->json(["Response" => $Content, "Message" => "Information registered successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error registering information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function update_Content(Request $request) {
        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $ID = $request->content_id;
            $TITLE = $request->content_title;
            $CONTENT = $request->content_data;
            $ADITIONAL = $request->content_aditional;
            $DATE = date("Y-m-d H:i:s");
            $TYPE = $request->content_type;
            $SECTION = $request->content_section;
            $HIERARCHY = $request->content_hierarchy;
            $STATE = $request->content_state;
            $ENVIROMENT = $request->content_environment;
            $CATEGORY = $request->content_category;
            if($request->hasFile('content_path')){
                $PATH = $this->save_File($request->file('content_path'), $TYPE, $SECTION, $ENVIROMENT, $CATEGORY);
            }else{
                $PATH = $request->content_path;
            }
            if($request->hasFile('content_extra')){
                $EXTRA = $this->save_File($request->content_extra, $TYPE, $SECTION, $ENVIROMENT, $CATEGORY);
            }else{
                $EXTRA = $request->content_extra;
            }
            $Content = DB::update("CALL ContentCms_Update('$ID', '$TITLE', '$CONTENT', '$ADITIONAL', '$EXTRA', '$PATH', '$DATE', '$TYPE', '$SECTION', '$HIERARCHY', '$STATE', '$ENVIROMENT', '$CATEGORY');");
            
            if ($Content > 0) {
                return response()->json(["Response" => $Content, "Message" => "Information registered successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error registering information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function delete_Content(Request $request) {
        
        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);
        $ID = $request->content_id;

        if ($authorization == true) {

            $Content = DB::delete("CALL ContentCms_Delete('$ID');");
            if ($Content > 0) {
                return response()->json(["Response" => 1, "Message" => "Information deleted successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error deleting information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function save_File($FILE, $TYPE, $SECTION, $ENVIROMENT, $CATEGORY) {

        $file_ = explode(".", $FILE->getClientOriginalName());
        $path = 'app/Contenidos';
        $target = 'public/'.$path.'/';
        $name = date("Y") . "_" . date("m") . "_" . date("d") . "t" . $TYPE . "s" . $SECTION. "e" . $ENVIROMENT . "c" . $CATEGORY."id".uniqid();
        $ext = $file_[1];
        $newname = $name. "." . $ext;
        //echo $newname;
        //exit();

        $FILE->move($target, $newname);
        //Storage::disk('local')->putFileAs($target, new $FILE, $newname);
        return $newname;
    }


}
