<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: authtoken, userid');

//Common
Route::GET('contents/categories', 'CommonController@get_Categories');
Route::GET('contents/types', 'CommonController@get_ContentTypes');
Route::GET('common/enviroments', 'CommonController@get_Enviroment');
Route::GET('common/sections', 'CommonController@get_Sections');
Route::GET('common/states', 'CommonController@get_States');
Route::GET('common/statesByTypes/{id}', 'CommonController@get_StatesXTypes');
Route::GET('common/userTypes', 'CommonController@get_UserTypes');

//Contact
Route::GET('contact', 'ContactController@get_Contacts');
Route::GET('contact/id/{id}', 'ContactController@get_Contact');
Route::POST('contact', 'ContactController@insert_Contact');
Route::POST('contact/edit', 'ContactController@update_Contact');

//Contents
Route::GET('contents', 'ContentController@get_Content');
Route::GET('contents/id/{id}', 'ContentController@get_ContentXId');
Route::GET('contents/category/{id}', 'ContentController@get_ContentXCategory');
Route::GET('contents/section/{id}', 'ContentController@get_ContentXSection');
Route::GET('contents/type/{id}', 'ContentController@get_ContentXTContent');
Route::POST('contents', 'ContentController@insert_Content');
Route::POST('contents/edit', 'ContentController@update_Content');
Route::POST('contents/delete', 'ContentController@delete_Content');

//Content Type
Route::GET('contenttype', 'ContentTypeController@get_ContentTypes');
Route::GET('contenttype/id/{id}', 'ContentTypeController@get_ContentType');
Route::POST('contenttype/login', 'ContentTypeController@Login_ContentType');
Route::POST('contenttype', 'ContentTypeController@insert_ContentType');
Route::POST('contenttype/edit', 'ContentTypeController@update_ContentType');
Route::DELETE('contenttype/{id}', 'ContentTypeController@delete_ContentType');

//Tokens
Route::GET('tokens/{id}', 'TokensController@get_Tokens');
Route::GET('tokens/state/{token}', 'TokensController@get_TokenState');

//Users
Route::GET('users', 'UsersController@get_Users');
Route::GET('users/id/{id}', 'UsersController@get_UsersXId');
Route::POST('users/login', 'UsersController@Login_Users');
Route::POST('users', 'UsersController@insert_Users');
Route::POST('users/edit', 'UsersController@update_Users');
Route::POST('users/{id}', 'UsersController@delete_Users');

//Page
Route::GET('page/content/{content}/{section}/{enviroment}', 'ContentPageController@get_ContentPage');