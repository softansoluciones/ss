<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\TokensController;
use DB;

class EmailController extends Controller {

    public function EmailContact($NAME, $EMAIL, $RESPONSE) {

        ini_set('SMTP', 'mail.wilfridogonzalezescritor.com');
        ini_set('smtp_port', 587);

        $para = $EMAIL;
        $titulo = "Gracias por contactarme";

        $mensaje = "<html>
            <head>
            <meta charset='UTF-8'>
            <meta name='viewport' content='width=device-width, initial-scale=1'>
            <style>
            table {
            font-family: Arial;
            font-size: 80%;
            /*margin: 1%;*/
            width: auto;
            text-align: left;
            border-collapse: collapse;
            }
            th {
                font-weight: normal;
                padding: 1%;
                background: #388ed1;
                border-top: white solid 1px;
                border-bottom: white solid 1px;
                color: whitesmoke;
                font-weight: bold;
            }
            td {
                width: auto;
                padding: 1%;
                background: white;
                border: #388ed1 solid 1px;
                color: #669;
            }
            
            .responsivediv {
                overflow-x: auto;
            }
    
            .centered {
                display: flex;
                justify-content: center;
            }
    
            .button {
                background-color: #388ed1;
                color: white;
                font-weight: bolder;
                padding: 1%;
                border: #388ed1 solid 5px;
            }
    
            .footer {
                padding: 1%;
                font-weight: bold;
                font-size: 80%;
                text-align: center;
                background-color: #388ed1;
                color: white;
                position: inherit;
            }
        </style>
    <body class='centered'>
        <div class=''
            style='border: #388ed1 solid 4px; background-color: white; height: auto; width: 90%; margin: 4%; font-family: Arial;'>
            <div class='footer'>
                <img src='http://wilfridogonzalezescritor.com/media/logos/blanco.png' alt='' height='130' />
            </div>
            <div style=' margin: 1%; padding: 4%;'>
                <div class=''>
                    <h2 class='card-title text-center'>Estimado(a) ".$NAME."</h2>
                    <br>
                    <hr>
                    <p style='font-size: 120%;'>".$RESPONSE."</p>
                </div>
                <br>
            </div>
            <div class='footer'>
               <a href='http://wilfridogonzalezescritor.com' target='_blank' style='color: white; text-decoration: none;'><p>Wilfrido González Escritor</p></a>
            </div>
        </div>
    </body>
    
    </html>";

        $cabeceras = 'MIME-Version: 1.0' . "\r\n";
        $cabeceras .= 'Content-type: text/html; charset=utf-8' . "\r\n";
        $cabeceras .= 'From: Contacto Wilfrido González Escritor<contacto@wilfridogonzalezescritor.com>';

        $enviado = mail($para, $titulo, $mensaje, $cabeceras);

        if ($enviado)
            return 1;
        else
            return 0;
    }

}
