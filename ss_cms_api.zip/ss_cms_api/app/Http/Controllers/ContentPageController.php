<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\TokensController;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Storage;
use DB;


class ContentPageController extends Controller {

    public function get_ContentPage($content, $section, $enviroment, Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $Content = DB::select("call ContentPage_Get('$content', '$section', '$enviroment');");

            $rows = count($Content);

            if ($rows > 0) {
                return response()->json(["Response" => $Content, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function insert_Content(Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $TITLE = $request->content_title;
            $CONTENT = $request->content_data;
            $ADITIONAL = $request->content_aditional;
            $EXTRA = $request->content_extra;
            $DATE = date("Y-m-d H:i:s");
            $TYPE = $request->content_type;
            $SECTION = $request->content_section;
            $HIERARCHY = $request->content_hierarchy;
            $STATE = $request->content_state;
            $ENVIROMENT = $request->content_environment;
            $CATEGORY = $request->content_category;
            if($request->hasFile('content_path')){
                $PATH = $this->save_File($request->content_path, $TYPE, $SECTION, $ENVIROMENT, $CATEGORY);
            }else{
                $PATH = $request->content_path;
            }

            $Content = DB::select("CALL ContentCms_Add('$TITLE', '$CONTENT', '$ADITIONAL', '$EXTRA', '$PATH', '$DATE', '$TYPE', '$SECTION', '$HIERARCHY', '$STATE', '$ENVIROMENT', '$CATEGORY');");
            $rows = count($Content);
            if ($rows > 0) {
                return response()->json(["Response" => $Content, "Message" => "Information registered successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error registering information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

}
