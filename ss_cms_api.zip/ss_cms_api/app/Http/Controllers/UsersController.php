<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\TokensController;
use DB;

class UsersController extends Controller {

    public function get_Users(Request $request) {

        
        $token_in = $request->header('authtoken');
        $user__id = $request->header('userid');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {
            $users = DB::select("CALL Users_Get('$user__id');");
            $rows = count($users);
            if ($rows > 0) {
                return response()->json(["Response" => $users, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function get_UsersXId($id, Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $users = DB::select("call Users_GetXId('$id');");

            $rows = count($users);

            if ($rows > 0) {
                return response()->json(["Response" => $users, "Message" => "Ok"]);
            } else {
                return response()->json(["Response" => 0, "Message" => "No Data."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function Login_Users(Request $request) {

        $USER = $request->user_email;
        $PASSWORD = $request->user_password;

        $users = DB::select("CALL Users_Login('$USER', '$PASSWORD');");

        $rows = count($users);

        if ($rows > 0) {
            return response()->json(["Response" => $users, "Message" => "Ok"]);
        } else {
            return response()->json(["Response" => 0, "Message" => "No Data."]);
        }
    }

    public function insert_Users(Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $NAMES = $request->user_name;
            $LSTNAME = $request->user_lstname;
            $TEL = $request->user_tel;
            $EMAIL = $request->user_email;
            $PASSWORD = $request->user_password;
            $TYPE = $request->user_type;
            $STATE = $request->user_state;

            $users = DB::select("CALL Users_Add('$NAMES', '$LSTNAME', '$TEL', '$EMAIL', '$PASSWORD', '$TYPE', '$STATE');");
            $rows = count($users);
            if ($rows > 0) {
                return response()->json(["Response" => $users, "Message" => "Information registered successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error registering information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function update_Users(Request $request) {
        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $ID = $request->user_id;
            $NAMES = $request->user_name;
            $LSTNAME = $request->user_lstname;
            $TEL = $request->user_tel;
            $EMAIL = $request->user_email;
            $PASSWORD = $request->user_password;
            $PASSWORDVAL = $request->user_passwordval;
            $TYPE = $request->user_type;
            $STATE = $request->user_state;

            $users = DB::select("CALL Users_Update('$ID', '$NAMES', '$LSTNAME', '$TEL', '$EMAIL', '$PASSWORD', '$PASSWORDVAL', '$TYPE', '$STATE');");
            $rows = count($users);
            if ($rows > 0) {
                return response()->json(["Response" => $users, "Message" => "Information registered successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error registering information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

    public function delete_Users($id, Request $request) {

        $token_in = $request->header('authtoken');
        $token = new TokensController();
        $authorization = $token->TokenValidation($token_in);

        if ($authorization == true) {

            $users = DB::delete("CALL Users_Delete('$id');");
            if ($users > 0) {
                return response()->json(["Response" => 1, "Message" => "Information deleted successfully."]);
            } else {
                return response()->json(["Response" => 0, "Message" => "Error deleting information."]);
            }
        } else {
            return response()->json(["Response" => 228, "Message" => "Unauthorized."]);
        }
    }

}
