<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class CommonController extends Controller {

    public function get_Categories() {

        $categories = DB::select("CALL CategoriesCms_Get();");

        $rows = count($categories);

        if ($rows > 0) {
            return response()->json(["Response" => $categories, "Message" => "OK"]);
        } else {
            return response()->json(["Response" => 0, "Message" => "No Data"]);
        }
    }

    public function get_ContentTypes() {

        $types = DB::select("CALL ContentTypeCms_Get();");

        $rows = count($types);

        if ($rows > 0) {
            return response()->json(["Response" => $types, "Message" => "OK"]);
        } else {
            return response()->json(["Response" => 0, "Message" => "No Data"]);
        }
    }

    public function get_Enviroment() {

        $enviroment = DB::select("CALL Enviroment_Get();");

        $rows = count($enviroment);

        if ($rows > 0) {
            return response()->json(["Response" => $enviroment, "Message" => "OK"]);
        } else {
            return response()->json(["Response" => 0, "Message" => "No Data"]);
        }
    }

    public function get_Sections() {

        $sections = DB::select("CALL SectionsCms_Get();");

        $rows = count($sections);

        if ($rows > 0) {
            return response()->json(["Response" => $sections, "Message" => "OK"]);
        } else {
            return response()->json(["Response" => 0, "Message" => "No Data"]);
        }
    }

    public function get_States() {

        $states = DB::select("CALL states_Get();");

        $rows = count($states);

        if ($rows > 0) {
            return response()->json(["Response" => $states, "Message" => "OK"]);
        } else {
            return response()->json(["Response" => 0, "Message" => "No Data"]);
        }
    }

    public function get_StatesXTypes($id) {

        $states = DB::select("CALL states_GetXType('$id');");

        $rows = count($states);

        if ($rows > 0) {
            return response()->json(["Response" => $states, "Message" => "OK"]);
        } else {
            return response()->json(["Response" => 0, "Message" => "No Data"]);
        }
    }

    public function get_UserTypes() {

        $types = DB::select("CALL UserType_Get();");

        $rows = count($types);

        if ($rows > 0) {
            return response()->json(["Response" => $types, "Message" => "OK"]);
        } else {
            return response()->json(["Response" => 0, "Message" => "No Data"]);
        }
    }

}
